export interface userType {
    idUser: Number,
    nameUser: String,
    pesoUser: Number,
    senhaUser: String,
    emailUser: String
}
