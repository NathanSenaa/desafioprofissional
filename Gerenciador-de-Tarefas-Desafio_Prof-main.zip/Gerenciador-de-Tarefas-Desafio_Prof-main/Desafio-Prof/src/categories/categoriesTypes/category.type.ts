export interface categoryType {
    idCategory: Number,
    nameCategory: String,
    colorCategory: String 
}