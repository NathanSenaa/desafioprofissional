
    enum statusTask{
    pendente, 
    em_andamento, 
    concluida
    }

    export default statusTask